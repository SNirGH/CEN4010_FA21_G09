let navbar = document.querySelector('.navbar');
document.addEventListener('scroll', () => {
    if(window.top.scrollY > 19) {
        navbar.classList.add('scroll');
    }else{
        navbar.classList.remove('scroll');
        navbar.style.transition = '.4s ease';
    }
});

//login popup window

// Get the element with the specified ID
const signInButton = document.getElementById('subscription');

// Add a click event listener to the element
signInButton.addEventListener('click', popupWindow);

function popupWindow() {
    
  const width = 600;
  const height = 700;

  // calculate the center of the browser window
  const left = (window.innerWidth / 2)-(width / 2);
  const top = (window.innerHeight / 2)-(height / 2);

  const signinPage = window.open("signinPage.html", "Sign In", `width=${width}, height=${height}, left=${left}, top=${top}`);
}